import { Router } from 'express';
import { registra, login } from '../authController/authController'

const router = Router();

router.post('/registrar', registra);
router.post('/login', login);

export default router;
