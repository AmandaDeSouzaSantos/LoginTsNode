import { Request, Response } from "express";
import bcrypt from 'bcrypt';
import {db} from '../db';



export const registra = async (req: any,res:any) =>{
    const body = req.body
    console.log(body.user)


    try{
        const [usuarioExiste] = await db.query('SELECT * FROM users WHERE username = ?', [body.user])
        console.log(usuarioExiste)

        if(Array.isArray(usuarioExiste) && usuarioExiste.length > 0){
            return res.status(400).json({ error: 'Usuário já existe' });
        }

        const hashed = await bcrypt.hash(body.password, 10)

        await db.query('INSERT INTO users (username, password) VALUES (?, ?) ', [body.user, hashed])

        return res.status(201).json({ message: 'Usuário registrado com sucesso' });
   } catch (error){
    
        return res.status(500).json({ message: 'Deu RUIM', error: error})
   }
}

export const login = async (req: any , res: any)=>{
    const body = req.body
    console.log(body)
    try{
        const[rows]  = await db.query('SELECT * FROM users WHERE username = ?', [body.user])

        const users= rows as any[];

        console.log(users)
        console.log(rows)

        
        if(users.length === 0 ){
            return res.status(401).json({ message: 'USUARIO OU SENHA ERRADOS'})
        }

        const user = users[0]

        const senhaigual = await bcrypt.compare(body.password, user.password)

        if(!senhaigual){
             return res.status(401).json({ message: 'SENHA ERRADOS'})
        }

        return res.status(200).json({ message: 'Login'})

    }catch (error){
        return res.status(500).json({ message: 'Deu RUIM'})
   }

}